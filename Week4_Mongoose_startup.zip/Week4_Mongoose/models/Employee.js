const mongoose = require('mongoose');

const EmployeeSchema = new mongoose.Schema({
  firstname: {
    type: String
  },
  lastname: {
    type: String
  },
  email: {
    type: String
  },
  gender: {
    type: String
  },
  city:{
    type: String
  },
  designation: {
    type: String
  },
  salary: {
    type: Number
  },
  createdOn: { 
    type: Date
  },
  updatedOn: { 
    type: Date
  },
});

//Declare Virtual Fields


//Custom Schema Methods
//1. Instance Method Declaration


//2. Static method declararion


//Writing Query Helpers


//Pre middleware
EmployeeSchema.pre('save', function(){
  console.log("PRE - Save")

  let now = Date.now()
  this.updatedOn = now

  // Set a value for createdOn only if it is null
  if (!this.createdOn) {
    this.createdOn = now
  }

  console.log('PRE - SAVE - doc', this);
});

EmployeeSchema.pre('findOneAndUpdate', function(){
  console.log("PRE - findOneAndUpdate")

  let now = Date.now()
  this.updatedOn = now

  console.log(`PRE - findOneAndUpdate - doc updated on : ${this.updatedOn}`)
});

//Post middleware
EmployeeSchema.post('init', (doc) => {
  console.log('POST - init - %s has been initialized from the db', doc._id);
});

EmployeeSchema.post('validate', (doc) => {
  console.log('POST - validate - %s has been validated (but not saved yet)', doc._id);
});

EmployeeSchema.post('save', (doc) => {
  console.log('POST - save - %s has been saved', doc._id);
});

const Employee = mongoose.model("Employee", EmployeeSchema);
module.exports = Employee;